<div id="postbox-container-1" class="postbox-container">
	<div class="meta-box-sortables">
		<div class="postbox">
			<div class="handlediv" title="<?php _e( 'Click to toggle', '_dima_' ); ?>"><br></div>
			<h3 class="hndle"><span><?php _e( 'Save', '_dima_' ); ?></span></h3>
			<div class="inside">
				<p><?php _e( 'Once you are satisfied with your settings, click the button below to save them.', '_dima_' ); ?></p>
				<p class="cf"><input id="submit" class="button button-primary" type="submit"
				                     name="dima_uc_submit" value="Update"></p>
			</div>
		</div>
	</div>
</div>