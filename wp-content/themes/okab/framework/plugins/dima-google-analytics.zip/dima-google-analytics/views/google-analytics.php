<?php
/**
 * Plugin site output
 */

require( DIMA_GOOGLE_ANALYTICS_PATH . '/functions/options.php' );

echo $dima_google_analytics_code;