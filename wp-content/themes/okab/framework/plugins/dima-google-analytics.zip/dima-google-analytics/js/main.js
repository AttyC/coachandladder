jQuery(document).ready(function ($) {

    $('#submit').click(function () {
        $(this).addClass('saving').val('Updating');
    });
});